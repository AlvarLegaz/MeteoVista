/* File name: index.js */

//Previous: install libraries -> npm install express passport express-session cookie-parser// npm install passport passport-local

//Imports
const  express = require('express');
const path = require('path');
const passport = require('passport');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const LocalStrategy = require("passport-local").Strategy;

var mySecrect = 'este es mi secreto';

const app = express();

app.use(express.urlencoded({extended: true}));

app.use(cookieParser(mySecrect));

app.use(session({
  secret: mySecrect,
  resave: true,
  saveUninitialized: true 
}));

app.use(passport.initialize());
app.use(passport.session());


passport.use(new LocalStrategy(function(username,password,done){
  // username and password are the name of the input from html
  if(username === "user01" && password =="1234")
    return done(null, {id: 1, name:"User"});

  done (null, false);

}));

passport.serializeUser(function(user,done){
  done(null, user.id);
});

passport.deserializeUser(function(id,done){
  done(null, {id: 1, name:"User"});
});

app.use(express.static(path.join(__dirname, 'public')));

// Main root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Post with the values
app.post('/login', passport.authenticate('local',{
  successRedirect: '/StationsMeasurements',
  failureRedirect:"/"
}));

// Secundary roots:
app.get('/StationsMeasurements', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/StationsMeasurements.json'));
});

// Handler for error 404 (Page not found)
app.use((req, res, next) => {
  res.status(404).send('Sorry, page not found!');
});

// Init server at port 
const PORT = 80;
app.listen(PORT,running);

function running()
{
	console.log(`HTTP Server running at port: ${PORT}`);
}
